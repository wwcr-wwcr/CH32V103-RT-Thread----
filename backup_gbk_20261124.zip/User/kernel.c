#include "kernel.h"
#include "rtthread.h"
#include "lvgl/lvgl.h"

static rt_mq_t message_q = RT_NULL;        //key�߳��¼�����
static evt_handler_t event    = RT_NULL;   //�¼�����
static render_cb_t   render = RT_NULL;     //�¼�ˢ��

static void kernel_loop(void *parameter)
{
    message ev;

    (void)parameter;

    for(;;)
    {
        if(rt_mq_recv(message_q, &ev, sizeof(ev),
                      rt_tick_from_millisecond(10)) == RT_EOK)
        {
            if(event != RT_NULL)         //��û���¼�����
            {
                event(&ev);              /* ����������Ĵ������� */
            }
        }
        if(render != RT_NULL)
        {
            render();
        }
        lv_timer_handler();
    }
}


void kernel_post(uint8_t type, uint8_t code, int32_t value)     //�¼�����Ͷ��
{
    message ev = {type, code, value};

    if(message_q == RT_NULL)                    //���л�û����ֱ�Ӷ�
    {
        return;
    }

    rt_mq_send(message_q, &ev, sizeof(ev));
}


static struct rt_thread s_tid;                  //kernel�߳�
static rt_uint8_t s_stack[6144];                //kernel�߳�ջ
void kernel_run(evt_handler_t on_evt, render_cb_t on_render)
{
    event    = on_evt;                       //�¼����
    render = on_render;                    //�¼�����
    message_q = rt_mq_create("evt", sizeof(message), 8, RT_IPC_FLAG_FIFO);      //������Ϣ����
    rt_thread_init(&s_tid, 
                    "kernel", 
                    kernel_loop, 
                    RT_NULL,
                    s_stack, 
                    sizeof(s_stack), 
                    9, 
                    10);                            //�����߳�
    rt_thread_startup(&s_tid);
}

/**************************************************************************************************
 *                                        MSH ����
 **************************************************************************************************/
static void kernel_cmd(void)
{
}
MSH_CMD_EXPORT_ALIAS(kernel_cmd, kernel, show kernel loop counter);
